#!/bin/bash
# 더블클릭하면 로컬 서버가 뜨고 브라우저가 열립니다. 끌 때는 이 창에서 Ctrl+C.
cd "$(dirname "$0")" || exit 1

PORT=8765
while lsof -i :$PORT >/dev/null 2>&1; do PORT=$((PORT+1)); done

open_browser() { sleep 1; open "http://127.0.0.1:$PORT/index.html"; }

if command -v python3 >/dev/null 2>&1; then
  echo "→ http://127.0.0.1:$PORT/index.html  (끄려면 Ctrl+C)"
  open_browser &
  python3 -m http.server "$PORT" --bind 127.0.0.1
elif command -v npx >/dev/null 2>&1; then
  echo "→ http://127.0.0.1:$PORT/index.html  (끄려면 Ctrl+C)"
  open_browser &
  npx --yes http-server -p "$PORT" -a 127.0.0.1
else
  echo "python3도 node도 없습니다. index.html을 브라우저로 바로 열어도 동작합니다."
  open index.html
fi
